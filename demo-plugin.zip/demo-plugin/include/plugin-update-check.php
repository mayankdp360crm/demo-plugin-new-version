<?php
/**
 * Plugin update check
 *
 * @package demo_plugin
 */

/**
 * Push update when WordPress check update.
 *
 * @param array  $update The plugin update data.
 * @param array  $plugin_data Plugin headers.
 * @param string $plugin_file Plugin filename.
 * @param array  $locales Installed locales to look translations for.
 */
function demo_plugin_update_push( $update, $plugin_data, $plugin_file, $locales ) {

	if ( 'demo-plugin/demo-plugin.php' !== $plugin_file ) {
		return $update;
	}

	$update = array(
		'slug'       => 'demo-plugin',
		'version'    => '2.0.0',
		'url'        => 'https://raw.githubusercontent.com/mayankdp360crm/demo-plugin-new-version/main/demo-plugin-info.json',
		'package'    => 'https://github.com/mayankdp360crm/demo-plugin-new-version/blob/main/demo-plugin.zip?raw=true',
		'autoupdate' => false,
		'tested'     => '5.9',
		'banners'    => array(
			'low'  => 'http://wppmayankdev.wpengine.com/wp-content/uploads/2021/11/hero-video_1-scaled-1.jpeg',
			'high' => '',
		),
		'sections'   => array(
			'description'  => 'This plugin is used for plugin self updating capabilities',
			'installation' => 'Click the Insatall Update Now Button.',
			'changelog'    => '<h4>2.0.0 –  31 Dec 2021</h4><ul><li>Enhancements.</li><li>Initital Release.</li></ul>',
		),
	);

	return $update;
}

$remote_hostname = 'raw.githubusercontent.com';
add_filter( "update_plugins_{$remote_hostname}", 'demo_plugin_update_push', 10, 4 );
