<?php
/**
 * Plugin update check
 *
 * @package demo_plugin
 */

/**
 * Get the updated plugin info.
 */
function get_demo_plugin_info() {
	$json_args = array(
		'timeout' => 10,
		'headers' => array(
			'Accept' => 'application/json',
		),
	);

	$plugin_info = wp_remote_get(
		'https://raw.githubusercontent.com/mayankdp360crm/demo-plugin-new-version/main/demo-plugin-info.json',
		$json_args,
	);

	if ( ! empty( wp_remote_retrieve_body( $plugin_info ) ) && ! is_wp_error( $plugin_info ) ) {

		$plugin_info = json_decode( wp_remote_retrieve_body( $plugin_info ) );

		$info                   = array();
		$info['name']           = $plugin_info->wpp_demo_plugin_name;
		$info['slug']           = $plugin_info->wpp_demo_plugin_slug;
		$info['author']         = $plugin_info->wpp_demo_plugin_author;
		$info['author_profile'] = $plugin_info->wpp_demo_plugin_author_profile;
		$info['version']        = $plugin_info->wpp_demo_plugin_version;
		$info['download_link']  = $plugin_info->wpp_demo_plugin_download_url;
		$info['trunk']          = $plugin_info->wpp_demo_plugin_download_url;
		$info['last_updated']   = $plugin_info->wpp_demo_plugin_last_updated;
		$info['plugin']         = DEMO_PLUGIN_BASENAME;
		$info['new_version']    = $plugin_info->wpp_demo_plugin_version;
		$info['package']        = $plugin_info->wpp_demo_plugin_download_url;
		$info['sections']       = array(
			'description'  => $plugin_info->wpp_demo_plugin_sections->wpp_demo_plugin_description,
			'installation' => $plugin_info->wpp_demo_plugin_sections->wpp_demo_plugin_installation,
			'changelog'    => $plugin_info->wpp_demo_plugin_sections->wpp_demo_plugin_changelog,
		);

		$info['banners'] = array(
			'low'  => $plugin_info->wpp_demo_plugin_img->wpp_demo_plugin_low,
			'high' => $plugin_info->wpp_demo_plugin_img->wpp_demo_plugin_high,
		);
		set_transient( $info['slug'], (object) $info, 21600 );
		return (object) $info;
	}
}

add_filter( 'plugins_api', 'demo_plugin_details', 20, 3 );

/**
 * Check plugin info
 *
 * @param object $result .
 * @param string $action .
 * @param object $args .
 */
function demo_plugin_details( $result, $action, $args ) {
	$result = get_transient( 'demo-menu' );
	if ( 'plugin_information' === $action && false === $result ) {
		$result = get_demo_plugin_info();
	}

	if ( ! empty( $result ) && $result->slug === $args->slug ) {
		return $result;
	} else {
		return false;
	}
}

add_filter( 'site_transient_update_plugins', 'demo_show_update' );

/**
 * Show update message
 *
 * @param array $transient .
 */
function demo_show_update( $transient ) {
	$new_info = get_transient( 'demo-menu' );
	if ( ! empty( $transient->checked ) && false === $new_info ) {
		$new_info = get_demo_plugin_info();
	}

	if ( ! empty( $new_info ) && ! empty( $transient->checked[ $new_info->plugin ] ) && version_compare( DEMO_PLUGIN_VERSION, $new_info->version, '<' ) ) {
		$transient->response[ $new_info->plugin ] = $new_info;
		return $transient;
	} else {
		return $transient;
	}
}

add_action( 'upgrader_process_complete', 'demo_plugin_upgrade', 10, 2 );

/**
 * Change version of updated plugin.
 *
 * @param array $upgrader_data .
 * @param array $options .
 */
function demo_plugin_upgrade( $upgrader_data = array(), $options = array() ) {
	$new_info = get_demo_plugin_info();

	if ( 'update' === $options['action'] && 'plugin' === $options['type'] ) {
		foreach ( $options['plugins'] as $plugin_basename ) {
			if ( $plugin_basename === $new_info->plugin ) {
				update_option( 'demo_plugin_version', $new_info->version );
				delete_transient( 'demo-menu' );
			}
		}
	}
}
