<?php
/**
 * Plugin Name: Demo Plugin
 * Plugin URI: example.com
 * Description: This plugin is used for plugin self updating capabilities.
 * Version: 3.1.0
 * Author: WPP
 * Author URI: example.com
 *
 * @package    demo_plugin
 */

/**
 * Define Demo Plugin Directory.
 */
if ( ! defined( 'DEMO_PLUGIN_DIR' ) ) {
	define( 'DEMO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

/**
 * Define Demo Plugin Setting URI.
 */
if ( ! defined( 'DEMO_PLUGIN_URL' ) ) {
	define( 'DEMO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Define demo plugin basename.
 */
if ( ! defined( 'DEMO_PLUGIN_BASENAME' ) ) {
	define( 'DEMO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}

/**
 * Define Demo Plugin Version.
 */
if ( ! defined( 'DEMO_PLUGIN_VERSION' ) ) {
	$version = get_option( 'demo_plugin_version' );
	define( 'DEMO_PLUGIN_VERSION', $version );
}

register_activation_hook( __FILE__, 'demo_plugin_act' );

/**
 * Demo Plugin Current Version
 */
function demo_plugin_act() {
	add_option( 'demo_plugin_version', '3.1.0' );
}

require_once DEMO_PLUGIN_DIR . '/include/plugin-update-check.php';

add_action( 'admin_menu', 'wpp_demo_menu' );

/**
 * Show side bar menu
 */
function wpp_demo_menu() {
	add_menu_page(
		'Demo Plugin',
		'Demo Plugin',
		'manage_options',
		'demo-plugin',
		'demo_menu_view',
		'dashicons-cover-image',
		33
	);
}

/**
 * Show menu page
 */
function demo_menu_view() {
	echo '<h3>This is demo menu 3.1.0</h3>';
}
