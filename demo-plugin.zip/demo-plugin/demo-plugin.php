<?php
/**
 * Plugin Name: Demo Plugin
 * Plugin URI: example.com
 * Description: This plugin is used for plugin self updating capabilities.
 * Version: 2.0.0
 * Author: WPP
 * Author URI: example.com
 * Update URI: https://raw.githubusercontent.com/
 *
 * @package    demo_plugin
 */

/**
 * Security check.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define Demo Plugin Directory.
 */
if ( ! defined( 'DEMO_PLUGIN_DIR' ) ) {
	define( 'DEMO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

/**
 * Define Demo Plugin Setting URI.
 */
if ( ! defined( 'DEMO_PLUGIN_URL' ) ) {
	define( 'DEMO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

require_once DEMO_PLUGIN_DIR . '/include/plugin-update-check.php';

add_action( 'admin_menu', 'wpp_demo_menu' );

/**
 * Show side bar menu
 */
function wpp_demo_menu() {
	add_menu_page(
		'Demo Plugin',
		'Demo Plugin',
		'manage_options',
		'demo-plugin',
		'demo_menu_view',
		'dashicons-cover-image',
		33
	);
}

/**
 * Show menu page
 */
function demo_menu_view() {
	echo '<h3>This is demo menu 2.0.0</h3>';
}

