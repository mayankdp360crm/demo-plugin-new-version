<?php
/**
 * Plugin Name: Demo Plugin
 * Plugin URI: example.com
 * Description: This plugin is used for plugin self updating capabilities.
 * Version: 1.1.0
 * Author: WPP
 * Author URI: example.com
 * Update URI: https://raw.githubusercontent.com/
 *
 * @package    demo_plugin
 */

/**
 * Security check.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once DEMO_PLUGIN_DIR . '/include/plugin-update-check.php';

add_action( 'admin_menu', 'wpp_demo_menu' );

/**
 * Show side bar menu
 */
function wpp_demo_menu() {
	add_menu_page(
		'Demo Plugin',
		'Demo Plugin',
		'manage_options',
		'demo-plugin',
		'demo_menu_view',
		'dashicons-cover-image',
		33
	);
}

/**
 * Show menu page
 */
function demo_menu_view() {
	echo '<h3>This is demo menu 1.1.0</h3>';
}

