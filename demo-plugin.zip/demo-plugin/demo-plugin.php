<?php
/**
 * Plugin Name: Demo Plugin
 * Plugin URI: raw.githubusercontent.com
 * Description: This plugin is used for plugin self updating capabilities.
 * Version: 7.1.1
 * Author: WPP
 * Author URI: example.com
 * Update URI: https://raw.githubusercontent.com/mayankdp360crm/demo-plugin-new-version/main/demo-plugin-info.json
 * @package    demo_plugin
 */

/**
 * Security check.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define Demo Plugin Directory.
 */
if ( ! defined( 'DEMO_PLUGIN_DIR' ) ) {
	define( 'DEMO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

/**
 * Define Demo Plugin Setting URI.
 */
if ( ! defined( 'DEMO_PLUGIN_URL' ) ) {
	define( 'DEMO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

// require_once DEMO_PLUGIN_DIR . '/include/plugin-update-check.php';

add_action( 'admin_menu', 'wpp_demo_menu' );

/**
 * Show side bar menu
 */
function wpp_demo_menu() {
	add_menu_page(
		'Demo Plugin',
		'Demo Plugin',
		'manage_options',
		'demo-plugin',
		'demo_menu_view',
		'dashicons-cover-image',
		33
	);
}

/**
 * Show menu page
 */
function demo_menu_view() {
	echo '<h3>This is demo menu 7.1.1</h3>';
}

function my_test( $update, $plugin_data, $plugin_file, $locales ) {

	if ( 'demo-plugin/demo-plugin.php' !== $plugin_file ) {
		return $update;
	}

	$update = array(
		'slug'       => 'demo-plugin',
		'version'    => '6.6.0',
		'url'        => 'https://github.com/mayankdp360crm/demo-plugin-new-version/blob/main/',
		'package'    => 'https://github.com/mayankdp360crm/demo-plugin-new-version/blob/main/demo-plugin.zip?raw=true',
		'autoupdate' => false,
		'tested'     => '5.9',
		'banners'    => array(
			'low'  => 'http://wppmayankdev.wpengine.com/wp-content/uploads/2021/11/hero-video_1-scaled-1.jpeg',
			'high' => '',
		),

		'sections'   => (object) array(
			'description'  => 'This plugin is used for plugin self updating capabilities.',
			'installation' => 'Click the Insatall Update Now Button.',
			'changelog'    => '<h4>5.1.1 –  31 Dec 2021</h4><ul><li>Enhancements.</li><li>Initital Release.</li></ul>',
		),
	);

	return $update;
}

$myplugin = 'raw.githubusercontent.com';
add_filter( "update_plugins_{$myplugin}", 'my_test', 10, 4 );
